/**
 * AuraStore - E-Commerce Product Catalog
 * Rich dataset featuring high-definition photography, specifications, and variants
 */

const PRODUCTS = [
  {
    id: 1,
    name: "Aura Studio Wireless ANC Headphones",
    tagline: "Studio-grade acoustic precision with ultra-low latency",
    category: "audio",
    categoryLabel: "Audio & Tech",
    price: 249.99,
    originalPrice: 329.99,
    rating: 4.9,
    reviewsCount: 384,
    badge: "Best Seller",
    featured: true,
    inStock: true,
    stockCount: 14,
    colors: [
      { name: "Space Black", hex: "#1f2022" },
      { name: "Silver Frost", hex: "#d8dce3" },
      { name: "Midnight Navy", hex: "#1a2536" }
    ],
    sizes: ["Standard Fit"],
    images: [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Immerse yourself in sheer sonic excellence. Aura Studio combines custom 40mm beryllium drivers with hybrid Active Noise Cancellation to eliminate up to 98% of ambient distractions. Engineered for 45 hours of continuous battery life and wrapped in breathable memory foam leatherette.",
    features: [
      "Hybrid Active Noise Cancellation with Transparency Mode",
      "Audiophile-grade 40mm Beryllium Neodymium drivers",
      "Up to 45 hours playtime with USB-C quick recharge (10 min = 5 hours)",
      "Multi-point Bluetooth 5.3 connection (simultaneous laptop & phone)"
    ],
    specs: {
      "Frequency Response": "10Hz - 40,000Hz",
      "Battery Life": "45 Hours (ANC On)",
      "Connectivity": "Bluetooth 5.3 + 3.5mm Aux",
      "Weight": "250g",
      "Warranty": "2 Years Official Warranty"
    }
  },
  {
    id: 2,
    name: "Apex Chrono Pro Smartwatch",
    tagline: "Titanium chassis, AMOLED sapphire glass, bio-telemetry",
    category: "wearables",
    categoryLabel: "Wearables",
    price: 389.00,
    originalPrice: 449.00,
    rating: 4.8,
    reviewsCount: 219,
    badge: "Trending",
    featured: true,
    inStock: true,
    stockCount: 8,
    colors: [
      { name: "Titanium Gray", hex: "#63676c" },
      { name: "Obsidian Black", hex: "#111111" },
      { name: "Alpine Orange", hex: "#e65100" }
    ],
    sizes: ["42mm", "46mm"],
    images: [
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1544117518-30df578096a4?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Crafted from aerospace-grade Grade 5 titanium, the Apex Chrono Pro is the ultimate companion for endurance athletes, mountain explorers, and executives. Featuring dual-frequency multi-GNSS GPS, ECG heart mapping, and 14 days of typical battery life on a single charge.",
    features: [
      "1.43-inch Always-On Sapphire AMOLED display (1,500 nits)",
      "ECG, SpO2 blood oxygen, HRV, and sleep phase monitoring",
      "50-meter water resistance (5 ATM rated for open water swimming)",
      "Dual-frequency L1 + L5 GNSS navigation with offline topographical maps"
    ],
    specs: {
      "Display": "1.43\" AMOLED 466x466 (326 ppi)",
      "Water Resistance": "5 ATM / 50 meters",
      "Battery Life": "Up to 14 Days",
      "Sensors": "Optical Heart, ECG, Barometer, Compass, Gyro",
      "Compatibility": "iOS & Android"
    }
  },
  {
    id: 3,
    name: "Nike Air Pulse Velocity Runners",
    tagline: "Carbon-fiber propulsion plate with responsive responsive foam",
    category: "footwear",
    categoryLabel: "Footwear & Fashion",
    price: 179.95,
    originalPrice: 219.99,
    rating: 4.9,
    reviewsCount: 512,
    badge: "Popular",
    featured: true,
    inStock: true,
    stockCount: 19,
    colors: [
      { name: "Crimson Red", hex: "#d32f2f" },
      { name: "Triple Black", hex: "#1c1c1c" },
      { name: "Glacier White", hex: "#eef2f5" }
    ],
    sizes: ["US 8", "US 9", "US 10", "US 11", "US 12"],
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Break your personal marathon record. Built with a full-length curved carbon fiber plate embedded in dual-density nitrogen-infused foam, giving you spring-loaded energy return on every strike. Seamless breathable knit upper keeps your feet cool across high mileage.",
    features: [
      "Full-length curved carbon plate for explosive forward propulsion",
      "Supercritical nitrogen-infused midsole with 85% energy return",
      "Breathable mono-mesh upper with targeted anatomical reinforcement",
      "High-abrasion Continental-inspired rubber outsole for wet grip"
    ],
    specs: {
      "Heel-to-Toe Drop": "8 mm",
      "Weight": "218g (US Men's 9)",
      "Terrain": "Road, Track, Treadmill",
      "Arch Support": "Neutral",
      "Upper Material": "Recycled engineered Flymesh"
    }
  },
  {
    id: 4,
    name: "Keychron K8 Pro Custom Mechanical Keyboard",
    tagline: "Wireless hot-swappable QMK/VIA gasket-mounted acoustic board",
    category: "workspace",
    categoryLabel: "Home & Workspace",
    price: 139.50,
    originalPrice: 169.00,
    rating: 4.7,
    reviewsCount: 190,
    badge: "Staff Pick",
    featured: true,
    inStock: true,
    stockCount: 11,
    colors: [
      { name: "Charcoal Grey", hex: "#2b2d42" },
      { name: "Retro Cream", hex: "#f3ede2" }
    ],
    sizes: ["Red Switches (Linear)", "Brown Switches (Tactile)", "Blue Switches (Clicky)"],
    images: [
      "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1595225476474-87563907a212?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=800&auto=format&fit=crop&q=80"
    ],
    description: "The dream mechanical typing experience for coders, designers, and writers. Fully customizable with QMK/VIA open-source software, factory pre-lubed Gateron G Pro mechanical switches, multi-layer silicone sound dampening, and hot-swappable PCB so you can swap switches without soldering.",
    features: [
      "Hot-swappable 5-pin PCB supports Cherry, Gateron, Kailh switches",
      "Double-shot PBT keycaps with crisp OEM profile",
      "Seamless Bluetooth 5.1 connection up to 3 devices + wired Type-C",
      "Acoustic silicone sound pad & EVA foam for deep thock sound profile"
    ],
    specs: {
      "Layout": "Tenkeyless 87-Key (80%)",
      "Switch Type": "Gateron G Pro (Pre-lubed)",
      "Battery": "4000 mAh (up to 300 hrs typing)",
      "Backlight": "South-facing 14-Mode RGB",
      "Compatibility": "macOS / Windows / Linux / iOS"
    }
  },
  {
    id: 5,
    name: "Venture Modular Urban Backpack 28L",
    tagline: "Weatherproof Cordura ballistic nylon with magnetic Fidlock clasp",
    category: "lifestyle",
    categoryLabel: "Lifestyle & Gear",
    price: 165.00,
    originalPrice: 195.00,
    rating: 4.8,
    reviewsCount: 147,
    badge: "20% OFF",
    featured: false,
    inStock: true,
    stockCount: 16,
    colors: [
      { name: "Matte Black", hex: "#1a1a1a" },
      { name: "Slate Olive", hex: "#4b5320" },
      { name: "Steel Gray", hex: "#708090" }
    ],
    sizes: ["24L Standard", "28L Expandable"],
    images: [
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1546938576-6e6a64f317cc?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Engineered for commuter daily carry and weekend globetrotting. Crafted from 1000D water-repellent Cordura ballistic fabric with waterproof YKK Aquaguard zippers. Features a dedicated suspended 16-inch laptop cocoon, hidden passport pocket, and expandable clamshell luggage opening.",
    features: [
      "Suspended faux-fur lined laptop chamber (fits up to 16\" MacBook Pro)",
      "German magnetic Fidlock V-buckle for rapid one-handed access",
      "Ergonomic contoured EVA foam harness with airflow channels",
      "Luggage trolley pass-through sleeve for effortless airport travel"
    ],
    specs: {
      "Capacity": "28 Liters (Expandable to 32L)",
      "Dimensions": "48 x 32 x 18 cm",
      "Weight": "1.1 kg",
      "Material": "1000D Recycled Ballistic Nylon + DWR Coating",
      "Zippers": "YKK AquaGuard Weatherproof"
    }
  },
  {
    id: 6,
    name: "RayBan Minimalist Matte Aviators",
    tagline: "Polarized UV400 titanium frame with anti-reflective coating",
    category: "footwear",
    categoryLabel: "Footwear & Fashion",
    price: 185.00,
    originalPrice: 220.00,
    rating: 4.6,
    reviewsCount: 98,
    badge: "New",
    featured: false,
    inStock: true,
    stockCount: 7,
    colors: [
      { name: "Gold / Emerald Green", hex: "#d4af37" },
      { name: "Matte Black / Smoke", hex: "#262626" },
      { name: "Gunmetal / Sapphire", hex: "#53565a" }
    ],
    sizes: ["Standard (55mm)", "Large (58mm)"],
    images: [
      "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1508296695146-257a814070b4?w=800&auto=format&fit=crop&q=80"
    ],
    description: "A refined architectural take on the timeless aviator silhouette. Constructed with ultra-light surgical-grade Japanese titanium weighing just 18 grams. Equipped with 9-layer polarized crystal lenses that banish harsh glare while amplifying color contrast.",
    features: [
      "100% UV400 radiation protection against UVA, UVB, and UVC",
      "Scratch-resistant oleophobic coating repels oil and water fingerprints",
      "Flexible beta-titanium temples for pressure-free all-day wear",
      "Includes hard leather magnetic case and microfiber polishing cloth"
    ],
    specs: {
      "Frame Material": "Japanese Beta-Titanium",
      "Lens Material": "Ultra-thin Polarized Mineral Glass",
      "Total Weight": "18.5g",
      "UV Filter": "Category 3 (UV400)",
      "Origin": "Handcrafted in Japan"
    }
  },
  {
    id: 7,
    name: "Sonos Roam 360 Portable Hi-Fi Speaker",
    tagline: "Trueplay acoustic tuning, waterproof IP67, dual passive radiators",
    category: "audio",
    categoryLabel: "Audio & Tech",
    price: 159.00,
    originalPrice: 189.00,
    rating: 4.8,
    reviewsCount: 263,
    badge: "Top Rated",
    featured: false,
    inStock: true,
    stockCount: 15,
    colors: [
      { name: "Lunar White", hex: "#f8f9fa" },
      { name: "Shadow Black", hex: "#1e1e1e" },
      { name: "Forest Moss", hex: "#3b4d3c" }
    ],
    sizes: ["Standard"],
    images: [
      "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1545454675-3531b543be5d?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1518444065439-e933c06ce9cd?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Astonishingly deep bass and room-filling acoustics packed into an ultra-portable form factor. Automatic Trueplay dynamically tunes sound to the specific acoustics of your environment whether you're relaxing on the patio or camping by the lakeshore.",
    features: [
      "IP67 dustproof and waterproof (can be submerged in 1 meter of water for 30 min)",
      "Seamless Wi-Fi and Bluetooth streaming with Apple AirPlay 2",
      "10 hours of continuous playback per charge; Qi wireless charging compatible",
      "Trueplay tuning adjusts EQ in real-time based on surroundings"
    ],
    specs: {
      "Amplifiers": "Two Class-H digital amplifiers",
      "Waterproofing": "IP67 Rated",
      "Battery": "18Wh (10 Hours)",
      "Weight": "430g",
      "Wireless": "Wi-Fi (802.11 b/g/n/ac) + Bluetooth 5.0"
    }
  },
  {
    id: 8,
    name: "Fellow Carter Insulated Ceramic Tumbler",
    tagline: "True taste ceramic interior with splash-proof snap disc",
    category: "lifestyle",
    categoryLabel: "Lifestyle & Gear",
    price: 39.50,
    originalPrice: 48.00,
    rating: 4.9,
    reviewsCount: 421,
    badge: "Staff Pick",
    featured: false,
    inStock: true,
    stockCount: 25,
    colors: [
      { name: "Matte Black", hex: "#222222" },
      { name: "Warm Butter", hex: "#fad02c" },
      { name: "Earthy Terracotta", hex: "#c06c52" }
    ],
    sizes: ["12 oz (350ml)", "16 oz (470ml)"],
    images: [
      "https://images.unsplash.com/photo-1517256064527-09c73fc73e38?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1577937927133-66ef06acdf18?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Designed specifically to elevate your sensory coffee experience. Unlike stainless steel travel mugs that ruin subtle bean aromas, the Carter features a glass-slick ceramic interior coating so your specialty roast tastes exactly as the barista intended. Stays piping hot for 12 hours.",
    features: [
      "Ceramic interior coating eliminates metallic odors and flavor taint",
      "Double-wall vacuum 18/8 stainless steel keeps heat 12h, cold 24h",
      "Aromatic thin lip mimics a wine glass for enhanced bouquet tasting",
      "100% leak-proof 90-degree twist locking seal"
    ],
    specs: {
      "Material": "18/8 Stainless Steel, BPA-Free Plastic, Ceramic Coating",
      "Thermal Retention": "12 Hours Hot / 24 Hours Cold",
      "Lid Compatibility": "Fits standard Aeropress & drippers",
      "Capacity": "16 oz / 473 ml",
      "Dishwasher Safe": "Hand wash recommended"
    }
  },
  {
    id: 9,
    name: "Lumina Arc Smart Ambient Desk Bar",
    tagline: "Asymmetric optical glare-free lighting with wireless rotary dial",
    category: "workspace",
    categoryLabel: "Home & Workspace",
    price: 119.00,
    originalPrice: 145.00,
    rating: 4.7,
    reviewsCount: 168,
    badge: "Bestseller",
    featured: false,
    inStock: true,
    stockCount: 12,
    colors: [
      { name: "Anodized Space Gray", hex: "#4a4f54" },
      { name: "Arctic Silver", hex: "#e0e3e6" }
    ],
    sizes: ["Curved Screen Fit", "Flat Monitor Standard"],
    images: [
      "https://images.unsplash.com/photo-1534349762230-e0cadf78f5da?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Say goodbye to screen reflections and eye fatigue. Lumina Arc hangs gracefully on top of your monitor to light your desk area with calibrated Ra95 high color rendering index light without shining any direct glare into your eyes or onto your display surface.",
    features: [
      "Asymmetric optical projection completely prevents screen glare",
      "Wireless 2.4G metallic rotary puck controls brightness and kelvin warmth",
      "Auto-dimming ambient light sensor balances room illumination",
      "Stepless color temperature adjustment from 2700K (candle) to 6500K (daylight)"
    ],
    specs: {
      "Color Rendering Index": "Ra ≥ 95",
      "Color Temperature": "2700K - 6500K Stepless",
      "Power Interface": "USB Type-C (5V/1.5A)",
      "Compatibility": "1-3.2cm Monitor Thickness",
      "Lifespan": "35,000+ Hours"
    }
  },
  {
    id: 10,
    name: "Artisan Bifold Slim RFID Leather Wallet",
    tagline: "Full-grain vegetable-tanned Italian leather with quick-draw slot",
    category: "lifestyle",
    categoryLabel: "Lifestyle & Gear",
    price: 68.00,
    originalPrice: 85.00,
    rating: 4.8,
    reviewsCount: 310,
    badge: "Handcrafted",
    featured: false,
    inStock: true,
    stockCount: 22,
    colors: [
      { name: "Cognac Brown", hex: "#8b4513" },
      { name: "Midnight Charcoal", hex: "#2b2b2b" },
      { name: "Espresso Dark", hex: "#3d2314" }
    ],
    sizes: ["Slim (Holds 8-10 cards)"],
    images: [
      "https://images.unsplash.com/photo-1627123424574-724758594e93?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1556742049-0a67c5574f73?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1544816155-12df9643f363?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Handcrafted in Tuscany by generational leather masters. Made with certified vegetable-tanned full-grain leather that patinas gorgeously over years of daily carry. Includes integrated RFID shielding fabric to safeguard against unauthorized contactless scans.",
    features: [
      "Certified 100% full-grain Italian Tuscan vegetable-tanned leather",
      "Integrated military-spec RFID electromagnetic shielding barrier",
      "Exterior rapid-access thumb slot for your most frequent transit card",
      "Ultra-thin 0.8cm profile won't bulge in front or back pockets"
    ],
    specs: {
      "Dimensions": "10.2 x 7.6 x 0.8 cm",
      "Capacity": "Up to 10 cards + folded banknotes",
      "Weight": "44g",
      "RFID Protection": "13.56 MHz frequency barrier",
      "Packaging": "Delivered in gift box with certificate of authenticity"
    }
  },
  {
    id: 11,
    name: "TrueSound ANC Gen-2 Wireless Earbuds",
    tagline: "Lossless spatial audio with adaptive transparency & wireless case",
    category: "audio",
    categoryLabel: "Audio & Tech",
    price: 149.00,
    originalPrice: 199.00,
    rating: 4.7,
    reviewsCount: 342,
    badge: "Save 25%",
    featured: false,
    inStock: true,
    stockCount: 18,
    colors: [
      { name: "Pearl White", hex: "#f0f2f5" },
      { name: "Matte Slate", hex: "#33383f" }
    ],
    sizes: ["Ear tips S/M/L included"],
    images: [
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1598331668826-20cecc596b86?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Studio fidelity that fits neatly in your coin pocket. The TrueSound Gen-2 earbuds bring immersive spatial audio with dynamic head-tracking, crystal-clear beamforming microphone arrays, and intelligent wind-noise reduction for effortless calls anywhere.",
    features: [
      "Active Noise Cancellation reduces ambient noise by up to 35dB",
      "Spatial audio with dynamic head-tracking algorithm",
      "32 hours total battery life with fast Qi-compatible wireless case",
      "IPX5 sweat and water resistance for intense workouts"
    ],
    specs: {
      "Drivers": "11mm Liquid Crystal Polymer Drivers",
      "Bluetooth": "5.3 with AAC, LDAC, SBC Codecs",
      "Battery Playtime": "7.5h earbuds + 24.5h case",
      "Charging": "USB-C + Qi Wireless Charging",
      "Weight": "4.2g per earbud"
    }
  },
  {
    id: 12,
    name: "Merino Wool Minimalist Overshirt",
    tagline: "Superfine 100% Australian merino with horn buttons & natural stretch",
    category: "footwear",
    categoryLabel: "Footwear & Fashion",
    price: 135.00,
    originalPrice: 170.00,
    rating: 4.8,
    reviewsCount: 88,
    badge: "Trending",
    featured: false,
    inStock: true,
    stockCount: 10,
    colors: [
      { name: "Sand Oatmeal", hex: "#d8cbb8" },
      { name: "Dark Navy", hex: "#1d293d" },
      { name: "Forest Olive", hex: "#3e463a" }
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    images: [
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=800&auto=format&fit=crop&q=80"
    ],
    description: "The quintessential transitional layer. Spun from 19.5 micron Australian merino wool that naturally regulates your body temperature, wicks moisture away, and resists wrinkles and odors. Tailored with clean structured lines and genuine horn button closures.",
    features: [
      "100% natural superfine merino wool (non-mulesed certified)",
      "Thermo-regulating: keeps you warm in winter and cool in spring",
      "Natural anti-microbial fiber composition resists odors over multiple wears",
      "Dual chest flap pockets with concealed interior pen slot"
    ],
    specs: {
      "Fabric Weight": "280 g/m² Midweight Twill",
      "Fiber Micron": "19.5 Micron Superfine Merino",
      "Buttons": "Natural corozo horn buttons",
      "Care": "Dry clean or gentle cold wool wash",
      "Origin": "Milled in Biella, Italy"
    }
  }
];
