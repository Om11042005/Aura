/**
 * AURA E-Commerce Application Logic
 * Interactive cart, detailed product viewer, live filters, wishlist, checkout
 */

// Application State
const state = {
  products: PRODUCTS || [],
  cart: JSON.parse(localStorage.getItem('aura_cart') || '[]'),
  wishlist: JSON.parse(localStorage.getItem('aura_wishlist') || '[]'),
  selectedProduct: null,
  activeCategory: 'all',
  searchQuery: '',
  sortBy: 'featured',
  maxPrice: 450,
  inStockOnly: false,
  appliedPromo: null, // { code: 'AURA10', discountPercent: 0.10 }
  theme: localStorage.getItem('aura_theme') || 'light'
};

// Available Promo Codes
const VALID_PROMOS = {
  'AURA10': 0.10,
  'SAVE20': 0.20,
  'VIP30': 0.30
};

// DOM Content Loaded Initializer
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  setupEventListeners();
  updateCategoryCounts();
  renderProducts();
  updateCartUI();
  updateWishlistUI();
  initGoogleAnalyticsNotice();
});

/* ==========================================================================
   Google Analytics 4 (GA4) Helper
   ========================================================================== */
function initGoogleAnalyticsNotice() {
  const measurementId = window.GA_MEASUREMENT_ID || 'G-XXXXXXXXXX';
  if (measurementId === 'G-XXXXXXXXXX') {
    console.info(
      '%c[Google Analytics] Currently in preview mode with placeholder ID: G-XXXXXXXXXX.\nTo see live traffic in your Google Analytics dashboard, replace G-XXXXXXXXXX in index.html with your actual GA4 Measurement ID.',
      'color: #2563eb; font-weight: bold; font-size: 12px;'
    );
  } else {
    console.info(`[Google Analytics] Active with Measurement ID: ${measurementId}`);
  }
}

function trackGAEvent(eventName, params = {}) {
  try {
    if (typeof window.gtag === 'function') {
      window.gtag('event', eventName, params);
      console.log(`[GA4 Event] ${eventName}:`, params);
    }
  } catch (err) {
    console.warn('[GA4 Error]', err);
  }
}

/* ==========================================================================
   Theme Management
   ========================================================================== */
function initTheme() {
  document.body.className = state.theme === 'dark' ? 'dark-theme' : 'light-theme';
  const themeIcon = document.getElementById('themeIcon');
  if (themeIcon) {
    themeIcon.className = state.theme === 'dark' ? 'fa-regular fa-sun' : 'fa-regular fa-moon';
  }
}

function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('aura_theme', state.theme);
  initTheme();
  showToast(`Switched to ${state.theme} theme`, 'info');
}

/* ==========================================================================
   Category Counts
   ========================================================================== */
function updateCategoryCounts() {
  const counts = { all: state.products.length, audio: 0, wearables: 0, footwear: 0, workspace: 0, lifestyle: 0 };
  state.products.forEach(p => {
    if (counts[p.category] !== undefined) {
      counts[p.category]++;
    }
  });

  for (const cat in counts) {
    const el = document.getElementById(`count-${cat}`);
    if (el) el.textContent = counts[cat];
  }
}

/* ==========================================================================
   Product Grid Rendering & Filtering
   ========================================================================== */
function getFilteredAndSortedProducts() {
  let list = [...state.products];

  // Category filter
  if (state.activeCategory !== 'all') {
    list = list.filter(p => p.category === state.activeCategory);
  }

  // Search filter
  if (state.searchQuery.trim()) {
    const q = state.searchQuery.toLowerCase().trim();
    list = list.filter(p => 
      p.name.toLowerCase().includes(q) ||
      p.tagline.toLowerCase().includes(q) ||
      p.categoryLabel.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q)
    );
  }

  // Max price filter
  list = list.filter(p => p.price <= state.maxPrice);

  // In stock filter
  if (state.inStockOnly) {
    list = list.filter(p => p.inStock);
  }

  // Sort
  switch (state.sortBy) {
    case 'price-low':
      list.sort((a, b) => a.price - b.price);
      break;
    case 'price-high':
      list.sort((a, b) => b.price - a.price);
      break;
    case 'rating':
      list.sort((a, b) => b.rating - a.rating);
      break;
    case 'name':
      list.sort((a, b) => a.name.localeCompare(b.name));
      break;
    case 'featured':
    default:
      list.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
      break;
  }

  return list;
}

function renderProducts() {
  const grid = document.getElementById('productGrid');
  const noResults = document.getElementById('noResults');
  const itemsFoundText = document.getElementById('itemsFoundText');
  const activeTagChips = document.getElementById('activeTagChips');

  if (!grid) return;

  const filtered = getFilteredAndSortedProducts();

  // Update items found text
  if (itemsFoundText) {
    itemsFoundText.textContent = `Showing ${filtered.length} item${filtered.length === 1 ? '' : 's'}`;
  }

  // Active Tag Chips
  if (activeTagChips) {
    let chipsHtml = '';
    if (state.activeCategory !== 'all') {
      chipsHtml += `<span class="tag-chip">Category: ${getCategoryLabel(state.activeCategory)} <button onclick="selectCategory('all')" title="Remove">&times;</button></span>`;
    }
    if (state.searchQuery) {
      chipsHtml += `<span class="tag-chip">Search: "${escapeHtml(state.searchQuery)}" <button onclick="clearSearch()" title="Remove">&times;</button></span>`;
    }
    if (state.maxPrice < 450) {
      chipsHtml += `<span class="tag-chip">Max: $${state.maxPrice} <button onclick="resetPriceFilter()" title="Remove">&times;</button></span>`;
    }
    if (state.inStockOnly) {
      chipsHtml += `<span class="tag-chip">In Stock Only <button onclick="toggleInStock(false)" title="Remove">&times;</button></span>`;
    }
    activeTagChips.innerHTML = chipsHtml;
  }

  if (filtered.length === 0) {
    grid.innerHTML = '';
    if (noResults) noResults.style.display = 'block';
    return;
  }

  if (noResults) noResults.style.display = 'none';

  grid.innerHTML = filtered.map(product => {
    const isWishlisted = state.wishlist.includes(product.id);
    const badgeClass = getBadgeClass(product.badge);
    const discountPercent = product.originalPrice ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;

    return `
      <article class="product-card" data-product-id="${product.id}">
        <!-- Image & Top Badges -->
        <div class="card-media-wrapper" onclick="openProductModalById(${product.id})">
          <div class="card-badge-container">
            ${product.badge ? `<span class="product-badge ${badgeClass}">${escapeHtml(product.badge)}</span>` : ''}
            ${discountPercent > 0 ? `<span class="product-badge badge-discount-tag">-${discountPercent}%</span>` : ''}
          </div>

          <div class="card-actions-floating" onclick="event.stopPropagation();">
            <button class="card-action-btn ${isWishlisted ? 'active' : ''}" 
              onclick="toggleWishlist(${product.id})" 
              title="${isWishlisted ? 'Remove from wishlist' : 'Save to wishlist'}"
              aria-label="Toggle wishlist">
              <i class="${isWishlisted ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}"></i>
            </button>
            <button class="card-action-btn" 
              onclick="openProductModalById(${product.id})" 
              title="Quick view"
              aria-label="Quick view">
              <i class="fa-solid fa-magnifying-glass"></i>
            </button>
          </div>

          <img src="${product.images[0]}" alt="${escapeHtml(product.name)}" loading="lazy" id="cardImg-${product.id}">
        </div>

        <!-- Product Card Content -->
        <div class="card-content">
          <span class="card-category">${escapeHtml(product.categoryLabel)}</span>
          <h3 class="card-title" onclick="openProductModalById(${product.id})">${escapeHtml(product.name)}</h3>

          <!-- Star Rating -->
          <div class="card-rating-row">
            <div class="stars">
              ${renderStars(product.rating)}
            </div>
            <span class="reviews-count">(${product.reviewsCount})</span>
          </div>

          <!-- Color Swatches -->
          ${product.colors && product.colors.length > 1 ? `
            <div class="card-color-swatches" onclick="event.stopPropagation();">
              ${product.colors.map((c, i) => `
                <span class="color-dot ${i === 0 ? 'active' : ''}" 
                  style="background-color: ${c.hex};" 
                  title="${escapeHtml(c.name)}"
                  onclick="switchCardColor(${product.id}, ${i}, this)"></span>
              `).join('')}
            </div>
          ` : '<div style="height: 14px; margin-bottom: 1rem;"></div>'}

          <!-- Footer Price and Add to Cart -->
          <div class="card-footer">
            <div class="card-pricing">
              <span class="current-price">$${product.price.toFixed(2)}</span>
              ${product.originalPrice ? `<span class="original-price">$${product.originalPrice.toFixed(2)}</span>` : ''}
            </div>

            <button class="add-to-cart-btn" id="cardAddBtn-${product.id}" onclick="quickAddToCart(${product.id}, this)">
              <i class="fa-solid fa-plus"></i> Add
            </button>
          </div>
        </div>
      </article>
    `;
  }).join('');
}

function renderStars(rating) {
  let starsHtml = '';
  const fullStars = Math.floor(rating);
  const hasHalf = rating % 1 >= 0.5;

  for (let i = 0; i < fullStars; i++) {
    starsHtml += '<i class="fa-solid fa-star"></i>';
  }
  if (hasHalf) {
    starsHtml += '<i class="fa-solid fa-star-half-stroke"></i>';
  }
  const emptyStars = 5 - fullStars - (hasHalf ? 1 : 0);
  for (let i = 0; i < emptyStars; i++) {
    starsHtml += '<i class="fa-regular fa-star"></i>';
  }
  return starsHtml;
}

function getBadgeClass(badge) {
  if (!badge) return '';
  const b = badge.toLowerCase();
  if (b.includes('off') || b.includes('save') || b.includes('sale')) return 'badge-discount-tag';
  if (b.includes('best') || b.includes('top')) return 'badge-best-tag';
  if (b.includes('new')) return 'badge-new-tag';
  return 'badge-default-tag';
}

function getCategoryLabel(catKey) {
  const map = {
    all: 'All Products',
    audio: 'Audio & Tech',
    wearables: 'Wearables',
    footwear: 'Footwear & Fashion',
    workspace: 'Workspace',
    lifestyle: 'Lifestyle & Gear'
  };
  return map[catKey] || catKey;
}

function switchCardColor(productId, imageIndex, element) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  const imgEl = document.getElementById(`cardImg-${productId}`);
  if (imgEl && product.images[imageIndex]) {
    imgEl.src = product.images[imageIndex];
  }
  // Highlight active dot
  const parent = element.parentElement;
  if (parent) {
    parent.querySelectorAll('.color-dot').forEach(dot => dot.classList.remove('active'));
    element.classList.add('active');
  }
}

/* ==========================================================================
   Selected Item Modal / Product Detail Viewer
   ========================================================================== */
function openProductModalById(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;

  state.selectedProduct = {
    product: product,
    selectedImageIndex: 0,
    selectedColor: product.colors ? product.colors[0] : null,
    selectedSize: product.sizes ? product.sizes[0] : null,
    quantity: 1
  };

  renderProductModal();
  const modal = document.getElementById('productDetailModal');
  if (modal) {
    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  // Google Analytics: Track view_item
  trackGAEvent('view_item', {
    currency: 'USD',
    value: product.price,
    items: [{
      item_id: String(product.id),
      item_name: product.name,
      price: product.price,
      item_category: product.categoryLabel
    }]
  });
}

function closeProductModal() {
  const modal = document.getElementById('productDetailModal');
  if (modal) {
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
  state.selectedProduct = null;
}

function renderProductModal() {
  const container = document.getElementById('modalProductContent');
  if (!container || !state.selectedProduct) return;

  const { product, selectedImageIndex, selectedColor, selectedSize, quantity } = state.selectedProduct;
  const isWishlisted = state.wishlist.includes(product.id);
  const discountAmount = product.originalPrice ? (product.originalPrice - product.price).toFixed(2) : 0;
  const discountPercent = product.originalPrice ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;

  container.innerHTML = `
    <!-- Left Column: Image Gallery with Interactive Thumbnails -->
    <div class="modal-gallery-col">
      <div class="modal-main-image-wrap">
        <img src="${product.images[selectedImageIndex] || product.images[0]}" alt="${escapeHtml(product.name)}" id="modalMainImage">
      </div>
      <div class="modal-thumbnails-strip">
        ${product.images.map((imgUrl, idx) => `
          <div class="modal-thumb ${idx === selectedImageIndex ? 'active' : ''}" onclick="selectModalImage(${idx})">
            <img src="${imgUrl}" alt="Thumbnail ${idx + 1}">
          </div>
        `).join('')}
      </div>
    </div>

    <!-- Right Column: Product Information & Controls -->
    <div class="modal-info-col">
      <div class="modal-header-tag">
        <span class="modal-cat-tag">${escapeHtml(product.categoryLabel)}</span>
        <span class="stock-status-pill"><i class="fa-solid fa-circle-check"></i> In Stock (${product.stockCount} left)</span>
      </div>

      <h1 class="modal-product-title">${escapeHtml(product.name)}</h1>
      <p class="modal-tagline">${escapeHtml(product.tagline)}</p>

      <!-- Rating Row -->
      <div class="modal-rating-row">
        <div class="stars">
          ${renderStars(product.rating)}
        </div>
        <strong>${product.rating}</strong>
        <span class="reviews-count">• ${product.reviewsCount} customer reviews</span>
      </div>

      <!-- Pricing Row -->
      <div class="modal-pricing-row">
        <span class="modal-price">$${product.price.toFixed(2)}</span>
        ${product.originalPrice ? `
          <span class="modal-original-price">$${product.originalPrice.toFixed(2)}</span>
          <span class="modal-discount-pill">Save $${discountAmount} (${discountPercent}% OFF)</span>
        ` : ''}
      </div>

      <!-- Description -->
      <p class="modal-description">${escapeHtml(product.description)}</p>

      <!-- Color Variant Selector -->
      ${product.colors && product.colors.length > 0 ? `
        <div class="variant-section">
          <label class="variant-label">Color: <strong>${escapeHtml(selectedColor ? selectedColor.name : product.colors[0].name)}</strong></label>
          <div class="variant-color-options">
            ${product.colors.map(color => `
              <button class="color-choice-btn ${selectedColor && selectedColor.name === color.name ? 'selected' : ''}" 
                onclick="selectModalColor('${escapeHtml(color.name)}')">
                <span class="swatch" style="background-color: ${color.hex};"></span>
                <span>${escapeHtml(color.name)}</span>
              </button>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <!-- Size / Option Selector -->
      ${product.sizes && product.sizes.length > 0 ? `
        <div class="variant-section">
          <label class="variant-label">Option / Size: <strong>${escapeHtml(selectedSize || product.sizes[0])}</strong></label>
          <div class="variant-size-options">
            ${product.sizes.map(size => `
              <button class="size-choice-btn ${selectedSize === size ? 'selected' : ''}" 
                onclick="selectModalSize('${escapeHtml(size)}')">
                ${escapeHtml(size)}
              </button>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <!-- Quantity & Add to Cart -->
      <div class="modal-actions-row">
        <div class="quantity-controller">
          <button class="qty-btn" onclick="updateModalQuantity(-1)" aria-label="Decrease quantity">
            <i class="fa-solid fa-minus"></i>
          </button>
          <input type="text" class="qty-input" value="${quantity}" readonly aria-label="Current quantity">
          <button class="qty-btn" onclick="updateModalQuantity(1)" aria-label="Increase quantity">
            <i class="fa-solid fa-plus"></i>
          </button>
        </div>

        <button class="btn btn-primary modal-add-btn" id="modalAddToCartBtn" onclick="addSelectedModalProductToCart()">
          <i class="fa-solid fa-bag-shopping"></i> Add to Cart • $${(product.price * quantity).toFixed(2)}
        </button>

        <button class="icon-btn" onclick="toggleWishlist(${product.id}); renderProductModal();" title="Save to wishlist">
          <i class="${isWishlisted ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}" style="${isWishlisted ? 'color: var(--accent-rose);' : ''}"></i>
        </button>
      </div>

      <!-- Instant Buy Button -->
      <button class="btn btn-secondary btn-block" onclick="buyNowFromModal()">
        <i class="fa-solid fa-bolt"></i> Buy Now (Instant Checkout)
      </button>

      <!-- Tabs: Specifications & Highlights -->
      <div class="modal-tabs">
        <div class="tab-headers">
          <button class="tab-header-btn active" onclick="switchModalTab('features', this)">Highlights</button>
          <button class="tab-header-btn" onclick="switchModalTab('specs', this)">Technical Specs</button>
          <button class="tab-header-btn" onclick="switchModalTab('shipping', this)">Delivery & Returns</button>
        </div>

        <div class="tab-pane active" id="tab-features">
          <ul class="features-list">
            ${product.features.map(f => `
              <li><i class="fa-solid fa-check"></i> <span>${escapeHtml(f)}</span></li>
            `).join('')}
          </ul>
        </div>

        <div class="tab-pane" id="tab-specs">
          <table class="specs-table">
            <tbody>
              ${Object.entries(product.specs || {}).map(([key, val]) => `
                <tr>
                  <td>${escapeHtml(key)}</td>
                  <td>${escapeHtml(val)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>

        <div class="tab-pane" id="tab-shipping">
          <ul class="features-list">
            <li><i class="fa-solid fa-truck-fast"></i> <strong>Free Express Delivery:</strong> Orders over $75 qualify for complimentary 2-3 business day air shipping.</li>
            <li><i class="fa-solid fa-box-archive"></i> <strong>Eco-Friendly Packaging:</strong> Shipped in 100% recyclable molded fiber protective cushioning.</li>
            <li><i class="fa-solid fa-arrow-rotate-left"></i> <strong>30-Day Hassle-Free Returns:</strong> Full refunds within 30 days of receiving your item.</li>
          </ul>
        </div>
      </div>
    </div>
  `;
}

function selectModalImage(index) {
  if (!state.selectedProduct) return;
  state.selectedProduct.selectedImageIndex = index;
  const mainImg = document.getElementById('modalMainImage');
  if (mainImg) {
    mainImg.src = state.selectedProduct.product.images[index];
  }
  document.querySelectorAll('.modal-thumb').forEach((thumb, i) => {
    thumb.classList.toggle('active', i === index);
  });
}

function selectModalColor(colorName) {
  if (!state.selectedProduct) return;
  const color = state.selectedProduct.product.colors.find(c => c.name === colorName);
  if (color) {
    state.selectedProduct.selectedColor = color;
    renderProductModal();
  }
}

function selectModalSize(size) {
  if (!state.selectedProduct) return;
  state.selectedProduct.selectedSize = size;
  renderProductModal();
}

function updateModalQuantity(delta) {
  if (!state.selectedProduct) return;
  const next = state.selectedProduct.quantity + delta;
  if (next >= 1 && next <= state.selectedProduct.product.stockCount) {
    state.selectedProduct.quantity = next;
    renderProductModal();
  }
}

function switchModalTab(tabName, button) {
  document.querySelectorAll('.tab-header-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));

  button.classList.add('active');
  const target = document.getElementById(`tab-${tabName}`);
  if (target) target.classList.add('active');
}

function addSelectedModalProductToCart() {
  if (!state.selectedProduct) return;
  const { product, selectedColor, selectedSize, quantity } = state.selectedProduct;
  
  addToCart(product.id, {
    color: selectedColor ? selectedColor.name : 'Default',
    size: selectedSize || 'Standard',
    quantity: quantity
  });

  // Animated feedback on button
  const btn = document.getElementById('modalAddToCartBtn');
  if (btn) {
    btn.innerHTML = `<i class="fa-solid fa-check"></i> Added ${quantity} item${quantity > 1 ? 's' : ''}!`;
    btn.style.backgroundColor = 'var(--accent-emerald)';
    btn.style.color = '#fff';
    setTimeout(() => {
      closeProductModal();
      openCart();
    }, 700);
  }
}

function buyNowFromModal() {
  if (!state.selectedProduct) return;
  const { product, selectedColor, selectedSize, quantity } = state.selectedProduct;
  
  addToCart(product.id, {
    color: selectedColor ? selectedColor.name : 'Default',
    size: selectedSize || 'Standard',
    quantity: quantity
  });
  
  closeProductModal();
  openCheckout();
}

/* ==========================================================================
   Shopping Cart Management
   ========================================================================== */
function quickAddToCart(productId, buttonElement) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;

  addToCart(productId, {
    color: product.colors ? product.colors[0].name : 'Default',
    size: product.sizes ? product.sizes[0] : 'Standard',
    quantity: 1
  });

  // Visual feedback on card button
  if (buttonElement) {
    buttonElement.classList.add('added-animation');
    buttonElement.innerHTML = '<i class="fa-solid fa-check"></i> Added';
    setTimeout(() => {
      buttonElement.classList.remove('added-animation');
      buttonElement.innerHTML = '<i class="fa-solid fa-plus"></i> Add';
    }, 1200);
  }
}

function addToCart(productId, options = {}) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;

  const color = options.color || (product.colors ? product.colors[0].name : 'Default');
  const size = options.size || (product.sizes ? product.sizes[0] : 'Standard');
  const quantity = options.quantity || 1;

  // Check if item with exact variant already exists in cart
  const existingIndex = state.cart.findIndex(
    item => item.productId === productId && item.color === color && item.size === size
  );

  if (existingIndex > -1) {
    state.cart[existingIndex].quantity += quantity;
  } else {
    state.cart.push({
      productId: productId,
      name: product.name,
      price: product.price,
      image: product.images[0],
      color: color,
      size: size,
      quantity: quantity
    });
  }

  saveCart();
  updateCartUI();
  showToast(`Added "${product.name}" to cart`, 'success');

  // Google Analytics: Track add_to_cart
  trackGAEvent('add_to_cart', {
    currency: 'USD',
    value: product.price * quantity,
    items: [{
      item_id: String(product.id),
      item_name: product.name,
      price: product.price,
      item_variant: `${color} / ${size}`,
      quantity: quantity
    }]
  });
}

function updateCartQuantity(cartIndex, delta) {
  if (state.cart[cartIndex]) {
    state.cart[cartIndex].quantity += delta;
    if (state.cart[cartIndex].quantity <= 0) {
      removeFromCart(cartIndex);
      return;
    }
    saveCart();
    updateCartUI();
  }
}

function removeFromCart(cartIndex) {
  if (state.cart[cartIndex]) {
    const item = state.cart[cartIndex];
    state.cart.splice(cartIndex, 1);
    saveCart();
    updateCartUI();
    showToast(`Removed "${item.name}" from cart`, 'info');

    // Google Analytics: Track remove_from_cart
    trackGAEvent('remove_from_cart', {
      currency: 'USD',
      value: item.price * item.quantity,
      items: [{
        item_id: String(item.productId),
        item_name: item.name,
        price: item.price,
        quantity: item.quantity
      }]
    });
  }
}

function clearCart() {
  if (state.cart.length === 0) return;
  state.cart = [];
  saveCart();
  updateCartUI();
  showToast('Shopping cart cleared', 'info');
}

function saveCart() {
  localStorage.setItem('aura_cart', JSON.stringify(state.cart));
}

function computeCartTotals() {
  const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const totalCount = state.cart.reduce((sum, item) => sum + item.quantity, 0);

  // Promo discount
  let discountAmount = 0;
  if (state.appliedPromo) {
    discountAmount = subtotal * state.appliedPromo.discountPercent;
  }

  // Free shipping threshold = $75
  const shipping = subtotal > 75 || subtotal === 0 ? 0 : 9.99;
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const tax = taxableAmount * 0.08; // 8% estimated tax
  const grandTotal = taxableAmount + shipping + tax;

  return {
    subtotal,
    totalCount,
    discountAmount,
    shipping,
    tax,
    grandTotal
  };
}

function updateCartUI() {
  const totals = computeCartTotals();

  // Header badges & subtotal
  const badgeCount = document.getElementById('cartBadgeCount');
  const headerTotal = document.getElementById('cartHeaderTotal');
  const totalItemsCount = document.getElementById('cartTotalItemsCount');

  if (badgeCount) badgeCount.textContent = totals.totalCount;
  if (headerTotal) headerTotal.textContent = `$${totals.subtotal.toFixed(2)}`;
  if (totalItemsCount) totalItemsCount.textContent = totals.totalCount;

  // Shipping progress banner
  const shippingProgressText = document.getElementById('shippingProgressText');
  const shippingProgressBar = document.getElementById('shippingProgressBar');
  if (shippingProgressText && shippingProgressBar) {
    if (totals.subtotal >= 75) {
      shippingProgressText.innerHTML = '<i class="fa-solid fa-truck-fast"></i> You unlocked <strong>Free Express Shipping</strong>!';
      shippingProgressBar.style.width = '100%';
    } else {
      const remaining = (75 - totals.subtotal).toFixed(2);
      const percent = Math.min(100, Math.round((totals.subtotal / 75) * 100));
      shippingProgressText.innerHTML = `Add <strong>$${remaining}</strong> more for <strong>Free Express Shipping</strong>!`;
      shippingProgressBar.style.width = `${percent}%`;
    }
  }

  // Cart items list render
  const list = document.getElementById('cartItemsList');
  const cartFooter = document.getElementById('cartFooter');

  if (list) {
    if (state.cart.length === 0) {
      list.innerHTML = `
        <div class="empty-cart-state">
          <div class="empty-cart-icon"><i class="fa-solid fa-bag-shopping"></i></div>
          <h4>Your cart is empty</h4>
          <p>Discover our precision gear and add items to your selection.</p>
          <button class="btn btn-primary" onclick="closeCart(); document.getElementById('catalogSection').scrollIntoView({behavior:'smooth'});">
            Explore Collection
          </button>
        </div>
      `;
      if (cartFooter) cartFooter.style.display = 'none';
    } else {
      if (cartFooter) cartFooter.style.display = 'flex';
      list.innerHTML = state.cart.map((item, idx) => `
        <div class="cart-item-card">
          <div class="cart-item-thumb">
            <img src="${item.image}" alt="${escapeHtml(item.name)}">
          </div>
          <div class="cart-item-details">
            <h4 class="cart-item-title">${escapeHtml(item.name)}</h4>
            <span class="cart-item-variant">${escapeHtml(item.color)} • ${escapeHtml(item.size)}</span>
            <span class="cart-item-price">$${item.price.toFixed(2)}</span>
            <div class="cart-item-controls">
              <div class="cart-qty-ctrl">
                <button onclick="updateCartQuantity(${idx}, -1)" aria-label="Decrease">&minus;</button>
                <span>${item.quantity}</span>
                <button onclick="updateCartQuantity(${idx}, 1)" aria-label="Increase">&plus;</button>
              </div>
              <button class="remove-cart-item-btn" onclick="removeFromCart(${idx})" title="Remove item">
                <i class="fa-regular fa-trash-can"></i>
              </button>
            </div>
          </div>
          <div class="cart-item-total">
            <strong>$${(item.price * item.quantity).toFixed(2)}</strong>
          </div>
        </div>
      `).join('');
    }
  }

  // Cart Footer totals
  const subtotalEl = document.getElementById('cartSubtotal');
  const discountRow = document.getElementById('discountRow');
  const discountCodeName = document.getElementById('discountCodeName');
  const discountEl = document.getElementById('cartDiscount');
  const shippingEl = document.getElementById('cartShipping');
  const taxEl = document.getElementById('cartTax');
  const grandTotalEl = document.getElementById('cartGrandTotal');

  if (subtotalEl) subtotalEl.textContent = `$${totals.subtotal.toFixed(2)}`;
  if (shippingEl) shippingEl.textContent = totals.shipping === 0 ? 'FREE' : `$${totals.shipping.toFixed(2)}`;
  if (taxEl) taxEl.textContent = `$${totals.tax.toFixed(2)}`;
  if (grandTotalEl) grandTotalEl.textContent = `$${totals.grandTotal.toFixed(2)}`;

  if (discountRow) {
    if (state.appliedPromo && totals.discountAmount > 0) {
      discountRow.style.display = 'flex';
      if (discountCodeName) discountCodeName.textContent = `${state.appliedPromo.code} (${state.appliedPromo.discountPercent * 100}%)`;
      if (discountEl) discountEl.textContent = `-$${totals.discountAmount.toFixed(2)}`;
    } else {
      discountRow.style.display = 'none';
    }
  }
}

function openCart() {
  const drawer = document.getElementById('cartDrawer');
  const backdrop = document.getElementById('cartBackdrop');
  if (drawer && backdrop) {
    drawer.classList.add('active');
    backdrop.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeCart() {
  const drawer = document.getElementById('cartDrawer');
  const backdrop = document.getElementById('cartBackdrop');
  if (drawer && backdrop) {
    drawer.classList.remove('active');
    backdrop.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function applyPromoCode() {
  const input = document.getElementById('promoInput');
  const feedback = document.getElementById('promoFeedback');
  if (!input || !feedback) return;

  const code = input.value.trim().toUpperCase();
  if (!code) {
    feedback.textContent = 'Please enter a valid coupon code.';
    feedback.className = 'promo-feedback error';
    feedback.style.display = 'block';
    return;
  }

  if (VALID_PROMOS[code]) {
    state.appliedPromo = {
      code: code,
      discountPercent: VALID_PROMOS[code]
    };
    feedback.textContent = `Coupon "${code}" applied! You save ${VALID_PROMOS[code] * 100}% on your subtotal.`;
    feedback.className = 'promo-feedback success';
    feedback.style.display = 'block';
    updateCartUI();
    showToast(`Promo code ${code} applied!`, 'success');

    // Google Analytics: Track apply_coupon
    trackGAEvent('apply_coupon', {
      coupon_id: code,
      discount_percent: VALID_PROMOS[code] * 100
    });
  } else {
    feedback.textContent = `Coupon "${code}" is invalid or expired. Try "AURA10".`;
    feedback.className = 'promo-feedback error';
    feedback.style.display = 'block';
  }
}

/* ==========================================================================
   Wishlist Management
   ========================================================================== */
function toggleWishlist(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;

  const idx = state.wishlist.indexOf(productId);
  if (idx > -1) {
    state.wishlist.splice(idx, 1);
    showToast(`Removed "${product.name}" from wishlist`, 'info');
  } else {
    state.wishlist.push(productId);
    showToast(`Saved "${product.name}" to wishlist`, 'success');
  }

  localStorage.setItem('aura_wishlist', JSON.stringify(state.wishlist));
  updateWishlistUI();
  renderProducts();
}

function updateWishlistUI() {
  const count = state.wishlist.length;
  const badge = document.getElementById('wishlistCount');
  const totalCountEl = document.getElementById('wishlistTotalCount');
  if (badge) badge.textContent = count;
  if (totalCountEl) totalCountEl.textContent = count;

  const list = document.getElementById('wishlistItemsList');
  if (!list) return;

  const wishlistProducts = state.products.filter(p => state.wishlist.includes(p.id));

  if (wishlistProducts.length === 0) {
    list.innerHTML = `
      <div class="empty-cart-state">
        <div class="empty-cart-icon"><i class="fa-regular fa-heart"></i></div>
        <h4>Your wishlist is empty</h4>
        <p>Save items you love by tapping the heart icon on any product.</p>
      </div>
    `;
    return;
  }

  list.innerHTML = wishlistProducts.map(p => `
    <div class="cart-item-card">
      <div class="cart-item-thumb">
        <img src="${p.images[0]}" alt="${escapeHtml(p.name)}">
      </div>
      <div class="cart-item-details">
        <h4 class="cart-item-title">${escapeHtml(p.name)}</h4>
        <span class="cart-item-price">$${p.price.toFixed(2)}</span>
        <div class="cart-item-controls">
          <button class="btn btn-outline-sm" onclick="quickAddToCart(${p.id}); closeWishlist(); openCart();">
            <i class="fa-solid fa-bag-shopping"></i> Add to Cart
          </button>
          <button class="remove-cart-item-btn" onclick="toggleWishlist(${p.id})" title="Remove">
            <i class="fa-regular fa-trash-can"></i>
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function openWishlist() {
  const drawer = document.getElementById('wishlistDrawer');
  const backdrop = document.getElementById('wishlistBackdrop');
  if (drawer && backdrop) {
    drawer.classList.add('active');
    backdrop.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeWishlist() {
  const drawer = document.getElementById('wishlistDrawer');
  const backdrop = document.getElementById('wishlistBackdrop');
  if (drawer && backdrop) {
    drawer.classList.remove('active');
    backdrop.classList.remove('active');
    document.body.style.overflow = '';
  }
}

/* ==========================================================================
   Checkout Modal & Flow
   ========================================================================== */
function openCheckout() {
  if (state.cart.length === 0) {
    showToast('Your cart is empty! Select items before checkout.', 'error');
    return;
  }

  closeCart();
  const modal = document.getElementById('checkoutModal');
  const formContainer = document.getElementById('checkoutFormContainer');
  const successScreen = document.getElementById('orderSuccessScreen');

  if (modal && formContainer && successScreen) {
    formContainer.style.display = 'grid';
    successScreen.style.display = 'none';
    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    renderCheckoutSummary();

    // Google Analytics: Track begin_checkout
    const totals = computeCartTotals();
    trackGAEvent('begin_checkout', {
      currency: 'USD',
      value: totals.grandTotal,
      items: state.cart.map(i => ({
        item_id: String(i.productId),
        item_name: i.name,
        price: i.price,
        item_variant: `${i.color} / ${i.size}`,
        quantity: i.quantity
      }))
    });
  }
}

function closeCheckout() {
  const modal = document.getElementById('checkoutModal');
  if (modal) {
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
}

function renderCheckoutSummary() {
  const totals = computeCartTotals();

  const preview = document.getElementById('checkoutItemsPreview');
  const countEl = document.getElementById('checkoutSummaryItemsCount');
  const subtotalEl = document.getElementById('checkoutSubtotal');
  const discountRow = document.getElementById('checkoutDiscountRow');
  const discountEl = document.getElementById('checkoutDiscount');
  const shippingEl = document.getElementById('checkoutShipping');
  const taxEl = document.getElementById('checkoutTax');
  const grandTotalEl = document.getElementById('checkoutGrandTotal');
  const payBtnAmount = document.getElementById('checkoutPayAmount');

  if (countEl) countEl.textContent = totals.totalCount;
  if (subtotalEl) subtotalEl.textContent = `$${totals.subtotal.toFixed(2)}`;
  if (shippingEl) shippingEl.textContent = totals.shipping === 0 ? 'FREE' : `$${totals.shipping.toFixed(2)}`;
  if (taxEl) taxEl.textContent = `$${totals.tax.toFixed(2)}`;
  if (grandTotalEl) grandTotalEl.textContent = `$${totals.grandTotal.toFixed(2)}`;
  if (payBtnAmount) payBtnAmount.textContent = `$${totals.grandTotal.toFixed(2)}`;

  if (discountRow) {
    if (state.appliedPromo && totals.discountAmount > 0) {
      discountRow.style.display = 'flex';
      if (discountEl) discountEl.textContent = `-$${totals.discountAmount.toFixed(2)}`;
    } else {
      discountRow.style.display = 'none';
    }
  }

  if (preview) {
    preview.innerHTML = state.cart.map(item => `
      <div class="checkout-preview-row">
        <div class="checkout-item-thumb">
          <img src="${item.image}" alt="${escapeHtml(item.name)}">
          <span class="checkout-item-badge">${item.quantity}</span>
        </div>
        <div class="checkout-preview-info">
          <div class="checkout-preview-title">${escapeHtml(item.name)}</div>
          <div class="checkout-preview-sub">${escapeHtml(item.color)} • ${escapeHtml(item.size)}</div>
        </div>
        <div class="checkout-preview-price">$${(item.price * item.quantity).toFixed(2)}</div>
      </div>
    `).join('');
  }
}

function handleCheckoutSubmit(e) {
  e.preventDefault();

  const placeOrderBtn = document.getElementById('placeOrderBtn');
  if (placeOrderBtn) {
    placeOrderBtn.disabled = true;
    placeOrderBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing Secure Payment...';
  }

  // Simulate payment gateway delay (1.2s)
  setTimeout(() => {
    const totals = computeCartTotals();
    const orderedItems = [...state.cart];

    // Reset button
    if (placeOrderBtn) {
      placeOrderBtn.disabled = false;
      placeOrderBtn.innerHTML = `<i class="fa-solid fa-lock"></i> Authorize & Place Order ($${totals.grandTotal.toFixed(2)})`;
    }

    // Switch to Confirmation Screen
    const formContainer = document.getElementById('checkoutFormContainer');
    const successScreen = document.getElementById('orderSuccessScreen');
    const receiptOrderNumber = document.getElementById('receiptOrderNumber');
    const receiptTotalAmount = document.getElementById('receiptTotalAmount');
    const receiptDeliveryDate = document.getElementById('receiptDeliveryDate');
    const successOrderedItems = document.getElementById('successOrderedItems');

    const randomOrderNumber = '#AUR-' + Math.floor(100000 + Math.random() * 900000);
    const deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + 3);
    const dateFormatted = deliveryDate.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });

    if (receiptOrderNumber) receiptOrderNumber.textContent = randomOrderNumber;
    if (receiptTotalAmount) receiptTotalAmount.textContent = `$${totals.grandTotal.toFixed(2)}`;
    if (receiptDeliveryDate) receiptDeliveryDate.textContent = `${dateFormatted} (Express Air)`;

    if (successOrderedItems) {
      successOrderedItems.innerHTML = orderedItems.map(item => `
        <img src="${item.image}" title="${escapeHtml(item.name)} (x${item.quantity})" alt="${escapeHtml(item.name)}">
      `).join('');
    }

    if (formContainer && successScreen) {
      formContainer.style.display = 'none';
      successScreen.style.display = 'flex';
    }

    // Clear cart
    state.cart = [];
    state.appliedPromo = null;
    saveCart();
    updateCartUI();

    // Google Analytics: Track purchase conversion
    trackGAEvent('purchase', {
      transaction_id: randomOrderNumber,
      value: totals.grandTotal,
      tax: totals.tax,
      shipping: totals.shipping,
      currency: 'USD',
      coupon: state.appliedPromo ? state.appliedPromo.code : undefined,
      items: orderedItems.map(i => ({
        item_id: String(i.productId),
        item_name: i.name,
        price: i.price,
        item_variant: `${i.color} / ${i.size}`,
        quantity: i.quantity
      }))
    });

    showToast('Order confirmed successfully!', 'success');
  }, 1200);
}

function closeOrderSuccessModal() {
  closeCheckout();
}

/* ==========================================================================
   Filter & Navigation Controls
   ========================================================================== */
function selectCategory(categoryKey) {
  state.activeCategory = categoryKey;

  // Sync desktop nav links
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.toggle('active', link.getAttribute('data-category') === categoryKey);
  });

  // Sync mobile nav links
  document.querySelectorAll('.mobile-nav-link').forEach(link => {
    link.classList.toggle('active', link.getAttribute('data-category') === categoryKey);
  });

  // Sync category pills
  document.querySelectorAll('.cat-pill').forEach(pill => {
    pill.classList.toggle('active', pill.getAttribute('data-category') === categoryKey);
  });

  closeMobileMenu();
  renderProducts();

  // Scroll to catalog section if not in view
  const catalogSection = document.getElementById('catalogSection');
  if (catalogSection && window.scrollY < catalogSection.offsetTop - 150) {
    catalogSection.scrollIntoView({ behavior: 'smooth' });
  }
}

function clearSearch() {
  state.searchQuery = '';
  const searchInput = document.getElementById('searchInput');
  const mobileSearchInput = document.getElementById('mobileSearchInput');
  const clearBtn = document.getElementById('clearSearchBtn');

  if (searchInput) searchInput.value = '';
  if (mobileSearchInput) mobileSearchInput.value = '';
  if (clearBtn) clearBtn.style.display = 'none';

  renderProducts();
}

function resetPriceFilter() {
  state.maxPrice = 450;
  const slider = document.getElementById('priceRange');
  const display = document.getElementById('priceDisplay');
  if (slider) slider.value = '450';
  if (display) display.textContent = '$450';
  renderProducts();
}

function toggleInStock(checked) {
  state.inStockOnly = checked;
  const checkbox = document.getElementById('inStockCheckbox');
  if (checkbox) checkbox.checked = checked;
  renderProducts();
}

function resetAllFilters() {
  state.activeCategory = 'all';
  state.searchQuery = '';
  state.sortBy = 'featured';
  state.maxPrice = 450;
  state.inStockOnly = false;

  const searchInput = document.getElementById('searchInput');
  const mobileSearchInput = document.getElementById('mobileSearchInput');
  const clearBtn = document.getElementById('clearSearchBtn');
  const slider = document.getElementById('priceRange');
  const display = document.getElementById('priceDisplay');
  const checkbox = document.getElementById('inStockCheckbox');
  const sortSelect = document.getElementById('sortSelect');

  if (searchInput) searchInput.value = '';
  if (mobileSearchInput) mobileSearchInput.value = '';
  if (clearBtn) clearBtn.style.display = 'none';
  if (slider) slider.value = '450';
  if (display) display.textContent = '$450';
  if (checkbox) checkbox.checked = false;
  if (sortSelect) sortSelect.value = 'featured';

  document.querySelectorAll('.nav-link').forEach(link => link.classList.toggle('active', link.getAttribute('data-category') === 'all'));
  document.querySelectorAll('.cat-pill').forEach(pill => pill.classList.toggle('active', pill.getAttribute('data-category') === 'all'));

  renderProducts();
  showToast('Filters reset to default', 'info');
}

/* ==========================================================================
   Mobile Menu Handlers
   ========================================================================== */
function openMobileMenu() {
  const panel = document.getElementById('mobileNavPanel');
  const overlay = document.getElementById('mobileOverlay');
  if (panel && overlay) {
    panel.classList.add('active');
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeMobileMenu() {
  const panel = document.getElementById('mobileNavPanel');
  const overlay = document.getElementById('mobileOverlay');
  if (panel && overlay) {
    panel.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

/* ==========================================================================
   Toast Notification System
   ========================================================================== */
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let icon = 'fa-solid fa-circle-info';
  if (type === 'success') icon = 'fa-solid fa-circle-check';
  if (type === 'error') icon = 'fa-solid fa-circle-exclamation';

  toast.innerHTML = `
    <i class="${icon}"></i>
    <span>${escapeHtml(message)}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

/* ==========================================================================
   Newsletter Subscription
   ========================================================================== */
function handleNewsletter(e) {
  e.preventDefault();
  const input = document.getElementById('newsletterEmail');
  if (input && input.value) {
    showToast(`Thank you! ${input.value} is now registered for early drops.`, 'success');
    input.value = '';
  }
}

/* ==========================================================================
   Helper Utilities
   ========================================================================== */
function escapeHtml(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/[&<>"']/g, match => {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
    return map[match];
  });
}

/* ==========================================================================
   Event Listeners Setup
   ========================================================================== */
function setupEventListeners() {
  // Theme Toggle
  const themeBtn = document.getElementById('themeToggleBtn');
  if (themeBtn) themeBtn.addEventListener('click', toggleTheme);

  // Cart Drawer Toggles
  const cartBtn = document.getElementById('cartToggleBtn');
  const closeCartBtn = document.getElementById('closeCartBtn');
  const cartBackdrop = document.getElementById('cartBackdrop');
  if (cartBtn) cartBtn.addEventListener('click', openCart);
  if (closeCartBtn) closeCartBtn.addEventListener('click', closeCart);
  if (cartBackdrop) cartBackdrop.addEventListener('click', closeCart);

  // Promo Code
  const applyPromoBtn = document.getElementById('applyPromoBtn');
  if (applyPromoBtn) applyPromoBtn.addEventListener('click', applyPromoCode);
  const promoInput = document.getElementById('promoInput');
  if (promoInput) {
    promoInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        applyPromoCode();
      }
    });
  }

  // Clear Cart
  const clearCartBtn = document.getElementById('clearCartBtn');
  if (clearCartBtn) clearCartBtn.addEventListener('click', clearCart);

  // Checkout Modal
  const openCheckoutBtn = document.getElementById('openCheckoutBtn');
  const closeCheckoutBtn = document.getElementById('closeCheckoutModalBtn');
  if (openCheckoutBtn) openCheckoutBtn.addEventListener('click', openCheckout);
  if (closeCheckoutBtn) closeCheckoutBtn.addEventListener('click', closeCheckout);

  // Wishlist Toggles
  const wishlistBtn = document.getElementById('wishlistToggleBtn');
  const closeWishlistBtn = document.getElementById('closeWishlistBtn');
  const wishlistBackdrop = document.getElementById('wishlistBackdrop');
  if (wishlistBtn) wishlistBtn.addEventListener('click', openWishlist);
  if (closeWishlistBtn) closeWishlistBtn.addEventListener('click', closeWishlist);
  if (wishlistBackdrop) wishlistBackdrop.addEventListener('click', closeWishlist);

  // Product Detail Modal
  const closeProdBtn = document.getElementById('closeProductModalBtn');
  const prodModal = document.getElementById('productDetailModal');
  if (closeProdBtn) closeProdBtn.addEventListener('click', closeProductModal);
  if (prodModal) {
    prodModal.addEventListener('click', (e) => {
      if (e.target === prodModal) closeProductModal();
    });
  }

  // Mobile Nav
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const closeMobileNavBtn = document.getElementById('closeMobileNavBtn');
  const mobileOverlay = document.getElementById('mobileOverlay');
  if (mobileMenuBtn) mobileMenuBtn.addEventListener('click', openMobileMenu);
  if (closeMobileNavBtn) closeMobileNavBtn.addEventListener('click', closeMobileMenu);
  if (mobileOverlay) mobileOverlay.addEventListener('click', closeMobileMenu);

  // Desktop Navigation Clicks
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      const cat = link.getAttribute('data-category');
      selectCategory(cat);
    });
  });

  // Mobile Navigation Clicks
  document.querySelectorAll('.mobile-nav-link').forEach(link => {
    link.addEventListener('click', () => {
      const cat = link.getAttribute('data-category');
      selectCategory(cat);
    });
  });

  // Category Pills Clicks
  document.querySelectorAll('.cat-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const cat = pill.getAttribute('data-category');
      selectCategory(cat);
    });
  });

  // Desktop Search
  const searchInput = document.getElementById('searchInput');
  const clearSearchBtn = document.getElementById('clearSearchBtn');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      state.searchQuery = e.target.value;
      if (clearSearchBtn) {
        clearSearchBtn.style.display = state.searchQuery ? 'block' : 'none';
      }
      renderProducts();
    });
  }
  if (clearSearchBtn) clearSearchBtn.addEventListener('click', clearSearch);

  // Mobile Search
  const mobileSearchInput = document.getElementById('mobileSearchInput');
  if (mobileSearchInput) {
    mobileSearchInput.addEventListener('input', (e) => {
      state.searchQuery = e.target.value;
      if (searchInput) searchInput.value = state.searchQuery;
      renderProducts();
    });
  }

  // Sort Dropdown
  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      state.sortBy = e.target.value;
      renderProducts();
    });
  }

  // Secondary Filter Toggle & Range
  const filterToggleBtn = document.getElementById('filterToggleBtn');
  const filterDrawer = document.getElementById('filterDrawer');
  if (filterToggleBtn && filterDrawer) {
    filterToggleBtn.addEventListener('click', () => {
      const isOpen = filterDrawer.style.display === 'block';
      filterDrawer.style.display = isOpen ? 'none' : 'block';
    });
  }

  const priceRange = document.getElementById('priceRange');
  const priceDisplay = document.getElementById('priceDisplay');
  if (priceRange) {
    priceRange.addEventListener('input', (e) => {
      state.maxPrice = Number(e.target.value);
      if (priceDisplay) priceDisplay.textContent = `$${state.maxPrice}`;
      renderProducts();
    });
  }

  const inStockCheckbox = document.getElementById('inStockCheckbox');
  if (inStockCheckbox) {
    inStockCheckbox.addEventListener('change', (e) => {
      state.inStockOnly = e.target.checked;
      renderProducts();
    });
  }

  const resetFiltersBtn = document.getElementById('resetFiltersBtn');
  if (resetFiltersBtn) {
    resetFiltersBtn.addEventListener('click', resetAllFilters);
  }

  // Card Payment method radio select toggle
  document.querySelectorAll('.payment-option input[type="radio"]').forEach(radio => {
    radio.addEventListener('change', () => {
      document.querySelectorAll('.payment-option').forEach(opt => opt.classList.remove('selected'));
      radio.closest('.payment-option').classList.add('selected');

      const cardFields = document.getElementById('cardFields');
      if (cardFields) {
        cardFields.style.display = radio.value === 'card' ? 'flex' : 'none';
      }
    });
  });

  // Global ESC Key Handler to Close Modals / Drawers
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeProductModal();
      closeCart();
      closeWishlist();
      closeCheckout();
      closeMobileMenu();
    }
  });
}
